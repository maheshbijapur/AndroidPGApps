package com.gae.scaffolder.plugin;


import com.marketo.Marketo;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService{
 
@Override
public void onNewToken(String s){
  super.onNewToken(s);
        Marketo marketoSdk = Marketo.getInstance(this.getApplicationContext());
        marketoSdk.setPushNotificationToken(s);
        Log.e("Push_Token",s);
  //Add your code here
}
 
@Override
public void onMessageReceived(RemoteMessage remoteMessage) {
  Log.d("MyFirebaseMessagingService", "onMessageReceived");

        Marketo marketoSdk = Marketo.getInstance(this.getApplicationContext());
        marketoSdk.showPushNotification(remoteMessage);
  //Add your code here
}
 
 
}