cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-fcm-with-dependecy-updated.FCMPlugin",
      "file": "plugins/cordova-plugin-fcm-with-dependecy-updated/www/FCMPlugin.js",
      "pluginId": "cordova-plugin-fcm-with-dependecy-updated",
      "clobbers": [
        "FCM"
      ]
    },
    {
      "id": "com.marketo.plugin.MarketoPlugin",
      "file": "plugins/com.marketo.plugin/www/marketo.js",
      "pluginId": "com.marketo.plugin",
      "clobbers": [
        "window.marketo"
      ]
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-fcm-with-dependecy-updated": "7.8.0",
    "com.marketo.plugin": "0.9.1"
  };
});