//
//  AppDelegate+Marketo.h
//  PhoneGapSample
//
//  Created by Rohit Mahto on 16/06/16.
//
//

#import "AppDelegate.h"
#import <UserNotifications/UserNotifications.h>
@interface AppDelegate (Marketo) <UNUserNotificationCenterDelegate>

@end
