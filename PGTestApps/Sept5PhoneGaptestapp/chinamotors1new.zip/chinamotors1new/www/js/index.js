/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Wait for the deviceready event before using any of Cordova's device APIs.
// See https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
var app = {
    // Application Constructor
initialize: function() {
    document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
},
    
    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
onDeviceReady: function() {
    this.receivedEvent('deviceready');
    
    // This method will Initialize the Marketo Framework using Your MunchkinId and secret key
    marketo.initialize(
                       function() { console.log("MarketoSDK Init done."); } ,
                       function(error) { console.log("an error occurred:" + error); },
                       '997-MMJ-095', 'VTNOWERIeW5PcU1zSlEwTFJ4cTRha2p1'
                       );
    
    // For session tracking, please add following.
    marketo.onStart(
                    function(){console.log("onStart.");},
                    function(error){console.log("Failed to report onStart." + error);}
                    );
    
    // This function will Enable user notifications (will prompt the user to accept push notifications in iOS)
    marketo. initializeMarketoPush(
                                   function() { console.log("Marketo push successfully initialized."); } ,
                                   function(error) { console.log("an error occurred:" + error); },
                                   '350312872033'
                                   );
    
    // First create a lead as below
    var lead_obj = {};
    lead_obj[marketo.KEY_FIRST_NAME]= "Ravi";
    lead_obj[marketo.KEY_LAST_NAME]= "Phonegap";
    lead_obj[marketo.KEY_EMAIL]= "ravitest003@marketo.com";
    lead_obj[marketo.KEY_ADDRESS]= "901 Mariners Island Boulevard";
    lead_obj[marketo.KEY_CITY]= "San Mateo";
    lead_obj[marketo.KEY_STATE]= "CA";
    lead_obj[marketo.KEY_COUNTRY]= "USA";
    lead_obj[marketo.KEY_POSTAL_CODE]= "94404";
    lead_obj[marketo.KEY_GENDER]= "Male";

    // Use associate function to associate it.
    marketo.associateLead(
                          function() {
                          console.log("MarketoSDK : Lead Associated");
                          },
                          function(error) {
                          console.log("an error occurred:" + error);
                          },
                          JSON.stringify(lead_obj)
                          );
},
//loginAndAssociate: function() {
//    var email = document.getElementById('user-email').value;
//    var lead_obj = {};
//    lead_obj[marketo.KEY_FIRST_NAME]= "Phone";
//    lead_obj[marketo.KEY_LAST_NAME]= "Gap";
//    lead_obj[marketo.KEY_EMAIL]= email;
//    lead_obj[marketo.KEY_ADDRESS]= "demo address";
//    lead_obj[marketo.KEY_CITY]= "city";
//    lead_obj[marketo.KEY_STATE]= "state";
//    lead_obj[marketo.KEY_COUNTRY]= "country";
//    lead_obj[marketo.KEY_POSTAL_CODE]= "postalCode";
//    lead_obj[marketo.KEY_GENDER]= "gender";
//    marketo.associateLead(
//        function() {
//            console.log("MarketoSDK : Lead Associated");
//        },
//        function(error) {
//            console.log("an error occurred:" + error);
//        },
//        JSON.stringify(lead_obj)
//    );
//},
    
    // Update DOM on a Received Event
receivedEvent: function(id) {
    var parentElement = document.getElementById(id);
    var listeningElement = parentElement.querySelector('.listening');
    var receivedElement = parentElement.querySelector('.received');
    
    listeningElement.setAttribute('style', 'display:none;');
    receivedElement.setAttribute('style', 'display:block;');
    
    console.log('Received Event: ' + id);
}
};

app.initialize();